package com.evdrivematch.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.widget.*
import java.util.Locale
import kotlin.math.*

class MainActivity : Activity(), LocationListener {
    private lateinit var manager: LocationManager
    private lateinit var summary: TextView
    private lateinit var history: TextView
    private var tracking = false
    private var previous: Location? = null
    private var distanceM = 0.0
    private var grossKwh = 0.0
    private var regenKwh = 0.0
    private var brakeGentle = 0
    private var brakeModerate = 0
    private var brakeHarsh = 0
    private var samples = 0
    private var speedSum = 0.0
    private val massKg = 1900.0
    private var batteryKwh = 60.0
    private var baseKwhPerKm = 0.16
    private lateinit var modelPicker: Spinner
    private val evModels = arrayOf("Compact EV • 45 kWh • 14 kWh/100km", "Mid-size EV • 60 kWh • 16 kWh/100km", "Large SUV EV • 80 kWh • 21 kWh/100km")
    private val preferences by lazy { getSharedPreferences("trips", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 40, 30, 20) }
        val title = TextView(this).apply { text = "EV DriveMatch"; textSize = 27f }
        summary = TextView(this).apply { textSize = 18f; setPadding(0, 25, 0, 25) }
        modelPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, evModels); setSelection(1) }
        val start = Button(this).apply { text = "Start GPS Trip" }
        val stop = Button(this).apply { text = "Stop & Save Trip" }
        val hint = TextView(this).apply { text = "Prototype: keep this screen open while tracking. Regen is a modelled estimate, not actual battery energy. Assumes 1,900 kg EV. Choose a sample EV profile before recording. Profiles are illustrative, not real vehicle specifications." }
        history = TextView(this).apply { textSize = 14f; setPadding(0, 25, 0, 0) }
        root.addView(title); root.addView(modelPicker); root.addView(summary); root.addView(start); root.addView(stop); root.addView(hint); root.addView(history)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        modelPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                batteryKwh = doubleArrayOf(45.0, 60.0, 80.0)[position]
                baseKwhPerKm = doubleArrayOf(0.14, 0.16, 0.21)[position]
                refresh()
            }
        }
        start.setOnClickListener { startTrip() }
        stop.setOnClickListener { stopTrip() }
        refresh()
    }

    private fun startTrip() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42); return
        }
        modelPicker.isEnabled = false
        distanceM = 0.0; grossKwh = 0.0; regenKwh = 0.0
        brakeGentle = 0; brakeModerate = 0; brakeHarsh = 0; samples = 0; speedSum = 0.0
        previous = null; tracking = true
        try { manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 2f, this) }
        catch (e: Exception) { tracking = false; Toast.makeText(this, "Enable GPS location", Toast.LENGTH_LONG).show() }
        refresh()
    }

    private fun stopTrip() {
        if (!tracking) return
        tracking = false; manager.removeUpdates(this); modelPicker.isEnabled = true
        val line = String.format(Locale.US, "%.1f km | %.2f kWh net | %.2f kWh regen | gentle %d, moderate %d, harsh %d", distanceM / 1000, max(0.0, grossKwh - regenKwh), regenKwh, brakeGentle, brakeModerate, brakeHarsh)
        val old = preferences.getString("history", "") ?: ""
        preferences.edit().putString("history", (line + "\n" + old).take(5000)).apply()
        refresh()
    }

    override fun onLocationChanged(location: Location) {
        if (!tracking || location.accuracy > 50f) return
        val old = previous
        if (old != null) {
            val dt = (location.elapsedRealtimeNanos - old.elapsedRealtimeNanos) / 1e9
            if (dt in 0.5..15.0) {
                val meters = old.distanceTo(location).toDouble()
                val v1 = if (old.hasSpeed()) old.speed.toDouble() else 0.0
                val v2 = if (location.hasSpeed()) location.speed.toDouble() else meters / dt
                if (meters <= 70 * dt && v2 < 65) {
                    distanceM += meters
                    val avg = (v1 + v2) / 2
                    speedSum += v2; samples++
                    // Simplified traction energy estimate; excludes detailed terrain/temperature effects.
                    grossKwh += meters / 1000 * baseKwhPerKm
                    val decel = (v1 - v2) / dt
                    if (decel > 0.3) {
                        val efficiency = when {
                            decel < 1.2 -> { brakeGentle++; 0.70 }
                            decel < 2.8 -> { brakeModerate++; 0.50 }
                            else -> { brakeHarsh++; 0.20 }
                        }
                        // Deduct a rough rolling + aerodynamic road-load share before applying regen.
                        val roadLoadJ = (0.012 * massKg * 9.81 + 0.35 * avg * avg) * meters
                        val kineticJ = 0.5 * massKg * max(0.0, v1*v1-v2*v2)
                        val kinetic = max(0.0, kineticJ - roadLoadJ) / 3_600_000.0
                        // Limit per-sample regen to illustrative 50 kW maximum.
                        regenKwh += min(kinetic * efficiency, 50.0 * dt / 3600.0)
                    }
                }
            }
        }
        previous = location
        refresh()
    }

    private fun refresh() {
        val net = max(0.0, grossKwh - regenKwh)
        summary.text = String.format(Locale.US,
            "Status: %s\nDistance: %.2f km\nAverage sampled speed: %.1f km/h\nGross EV energy: %.3f kWh\nEstimated regen: %.3f kWh\nNet energy: %.3f kWh\nBattery used (%.0f kWh): %.2f%%\nBraking events: gentle %d / moderate %d / harsh %d",
            if (tracking) "Recording" else "Stopped", distanceM/1000, if (samples > 0) speedSum/samples*3.6 else 0.0,
            grossKwh, regenKwh, net, batteryKwh, net/batteryKwh*100, brakeGentle, brakeModerate, brakeHarsh)
        history.text = "Saved trips (local):\n" + (preferences.getString("history", "") ?: "No trips yet")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startTrip()
    }
    override fun onDestroy() { if (tracking) manager.removeUpdates(this); super.onDestroy() }
}
