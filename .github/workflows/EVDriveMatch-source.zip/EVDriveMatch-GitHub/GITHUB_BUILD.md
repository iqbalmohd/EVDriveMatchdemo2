# Build EV DriveMatch APK with GitHub Actions

1. Create a GitHub repository (for example `EVDriveMatch`).
2. Upload **the contents** of this project folder to the repository root. Ensure `.github/workflows/build-apk.yml` is included (hidden folders can be missed in some upload interfaces).
3. Commit the files to `main`.
4. Open **Actions** > **Build Android APK** > **Run workflow**, or use the automatic build triggered by the commit.
5. Wait for the build to finish successfully, then open the run and download the `EVDriveMatch-debug-apk` artifact.
6. Unzip the artifact to obtain `app-debug.apk`, then transfer it to your Android phone and install it (you may need to permit installs from that source).

The APK is **debug-signed** for personal testing, not a production Google Play release. For Play Store publishing, configure a release signing key, build an Android App Bundle (AAB), comply with Play policies, and complete testing/review.

**Scope:** This is the phone-based prototype with manual GPS tracking and simulated EV energy/regen. It does not contain an approved Android Auto car-screen interface. GPS recording requires the activity to remain open. Results are estimates, not measurements of an EV's real battery.

If the build fails, open the failed job and inspect the `Build debug APK` log. The GitHub runner downloads Android dependencies during the build.
