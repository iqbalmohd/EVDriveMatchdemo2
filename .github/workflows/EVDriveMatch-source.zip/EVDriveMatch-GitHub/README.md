# EV DriveMatch — Google Play-safe Android phone prototype

This is a Kotlin Android Studio source project for the **phone** component. It is **not** a functioning Android Auto head-unit app, nor an approved Google Play release. Google Play does not currently permit a generic driving analytics dashboard as an Android Auto category. No false category declaration is included.

## Working prototype features
- Foreground-activity GPS trip tracking (screen must stay open)
- Trip distance, sampled speed, gentle/moderate/harsh deceleration counts
- Simplified kinetic energy regenerative-braking estimate, including approximate road load and 50 kW regen cap
- Three illustrative EV size profiles (45/60/80 kWh), selectable before starting a trip
- Battery use simulation and local saved-trip history

## Build
1. Open this folder in Android Studio with Android SDK 35 and JDK 17.
2. Let Gradle sync; ensure your Android Studio supplies the Gradle wrapper or use the installed Gradle build command.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Grant location permission on your phone.

## Limitations and compliance
- No installable APK is bundled; this environment has no Android SDK/Gradle build tools.
- Tracking stops when activity is destroyed; background tracking and connection-triggered recording are not implemented.
- GPS deceleration is not direct brake-pedal measurement. Regen and consumption are rough simulations; never use for trip-critical range planning.
- Real EV catalogue, charging station discovery, maps/navigation and recommendation ranking are not implemented.
- An Android Auto charging POI module would need real, current charging-station data, charging-focused templates, correct category declarations, and Play review. It is deliberately **not** added as a misleading stub.
- No external data transfer or advertising in this prototype. Review Play Data Safety and location disclosure before publishing.
